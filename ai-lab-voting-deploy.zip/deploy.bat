@echo off
echo 正在部署到GitHub Pages...
echo.

echo 1. 初始化Git仓库...
git init

echo 2. 添加远程仓库...
git remote add origin https://github.com/jinlinhu/ai-lab-voting.git

echo 3. 配置用户信息...
git config user.email "jinlinhu@example.com"
git config user.name "jinlinhu"

echo 4. 添加所有文件...
git add .

echo 5. 提交更改...
git commit -m "部署AI拓边实验室投票报名系统"

echo 6. 推送到GitHub...
echo 注意：如果推送失败，请检查网络连接或GitHub凭据
git push -u origin master

echo.
echo 部署完成！
echo 请访问：https://jinlinhu.github.io/ai-lab-voting/
pause